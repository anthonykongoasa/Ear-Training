import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const body = await request.json();
    const {
      sessionType,
      score,
      accuracyPercentage,
      notesPlayed,
      userResponses,
      settings,
      userId = null,
    } = body;

    if (
      !sessionType ||
      score === undefined ||
      !accuracyPercentage ||
      !notesPlayed ||
      !userResponses ||
      !settings
    ) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }

    const result = await sql`
      INSERT INTO sessions (
        user_id,
        session_type,
        score,
        accuracy_percentage,
        notes_played,
        user_responses,
        settings
      )
      VALUES (
        ${userId},
        ${sessionType},
        ${score},
        ${accuracyPercentage},
        ${JSON.stringify(notesPlayed)},
        ${JSON.stringify(userResponses)},
        ${JSON.stringify(settings)}
      )
      RETURNING id, created_at
    `;

    return Response.json({
      success: true,
      sessionId: result[0].id,
      createdAt: result[0].created_at,
    });
  } catch (error) {
    console.error("Error creating session:", error);
    return Response.json(
      { error: "Failed to create session" },
      { status: 500 },
    );
  }
}
