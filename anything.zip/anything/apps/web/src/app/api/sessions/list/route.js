import sql from "@/app/api/utils/sql";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId") || null;
    const limit = parseInt(searchParams.get("limit") || "50");

    let sessions;
    if (userId) {
      sessions = await sql`
        SELECT * FROM sessions
        WHERE user_id = ${userId}
        ORDER BY created_at DESC
        LIMIT ${limit}
      `;
    } else {
      sessions = await sql`
        SELECT * FROM sessions
        ORDER BY created_at DESC
        LIMIT ${limit}
      `;
    }

    return Response.json({
      sessions,
      count: sessions.length,
    });
  } catch (error) {
    console.error("Error fetching sessions:", error);
    return Response.json(
      { error: "Failed to fetch sessions" },
      { status: 500 },
    );
  }
}
