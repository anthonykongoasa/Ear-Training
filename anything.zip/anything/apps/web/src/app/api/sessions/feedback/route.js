export async function POST(request) {
  try {
    const body = await request.json();
    const {
      notesPlayed,
      userResponses,
      score,
      accuracy,
      settings,
      sessionKey,
      sessionMode,
      timeSig,
    } = body;

    let correctCount = 0;
    let mistakes = [];
    userResponses.forEach((response, index) => {
      if (response) {
        if (response.expected === response.actual) {
          correctCount++;
        } else {
          mistakes.push({
            index: index + 1,
            expected: response.expected,
            actual: response.actual,
          });
        }
      }
    });

    const mistakesSummary =
      mistakes.length > 0
        ? mistakes
            .slice(0, 5)
            .map(
              (m) =>
                `Note ${m.index}: expected ${m.expected}, played ${m.actual}`,
            )
            .join("; ")
        : "None";

    const keyInfo = sessionKey
      ? `${sessionKey} ${sessionMode || "major"}`
      : settings?.key || "unknown";

    const aiResponse = await fetch("/integrations/google-gemini-2-5-flash/", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: [
          {
            role: "system",
            content:
              "You are an expert ear training coach. Provide concise, actionable feedback in 2-4 sentences. Be encouraging but specific about what to improve.",
          },
          {
            role: "user",
            content: `Ear training session results:
- Key: ${keyInfo}  |  Time signature: ${timeSig || settings?.timeSignature || "4/4"}
- Clef: ${settings?.clef || "treble"}  |  Difficulty: ${settings?.difficulty || "medium"}
- Score: ${score}%  |  Accuracy: ${accuracy}%
- Correct: ${correctCount}/${notesPlayed.length} notes
- Input mode: ${settings?.inputMode || "microphone"}
- Mistakes (first 5): ${mistakesSummary}

Give specific feedback on: pitch recognition accuracy, patterns in the mistakes (e.g., always sharp, trouble with certain intervals), and a concrete practice tip tailored to the key and difficulty level.`,
          },
        ],
      }),
    });

    if (!aiResponse.ok) throw new Error("AI integration failed");
    const aiData = await aiResponse.json();
    const feedback = aiData.choices[0].message.content;

    return Response.json({
      feedback,
      analysis: {
        correctCount,
        totalNotes: notesPlayed.length,
        mistakesCount: mistakes.length,
      },
    });
  } catch (error) {
    console.error("Error generating feedback:", error);
    return Response.json(
      {
        error: "Failed",
        feedback:
          "Great effort! Keep practicing — consistency is the key to improving your ear.",
      },
      { status: 500 },
    );
  }
}
