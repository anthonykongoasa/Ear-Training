import { View, Text, ScrollView, TouchableOpacity } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { useState } from "react";
import { useRouter } from "expo-router";
import { Play } from "lucide-react-native";

// ── Shared UI Helpers ────────────────────────────────────────────
const Card = ({ title, subtitle, children }) => (
  <View
    style={{
      backgroundColor: "#FFFFFF",
      borderRadius: 12,
      borderWidth: 1,
      borderColor: "#E5E7EB",
      padding: 20,
      marginBottom: 16,
    }}
  >
    <Text
      style={{
        fontSize: 16,
        fontWeight: "600",
        color: "#111827",
        marginBottom: subtitle ? 4 : 12,
      }}
    >
      {title}
    </Text>
    {subtitle ? (
      <Text style={{ fontSize: 12, color: "#9CA3AF", marginBottom: 12 }}>
        {subtitle}
      </Text>
    ) : null}
    {children}
  </View>
);

const SingleSelect = ({ options, value, onChange }) => (
  <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
    {options.map((opt) => {
      const val = typeof opt === "object" ? opt.value : opt;
      const label = typeof opt === "object" ? opt.label : String(opt);
      const active = value === val;
      return (
        <TouchableOpacity
          key={String(val)}
          onPress={() => onChange(val)}
          style={{
            paddingVertical: 8,
            paddingHorizontal: 14,
            borderRadius: 999,
            borderWidth: 1,
            borderColor: active ? "#2563EB" : "#E5E7EB",
            backgroundColor: active ? "#EFF6FF" : "#FFFFFF",
          }}
        >
          <Text
            style={{
              fontSize: 13,
              fontWeight: "500",
              color: active ? "#2563EB" : "#6B7280",
            }}
          >
            {label}
          </Text>
        </TouchableOpacity>
      );
    })}
  </View>
);

const MultiSelect = ({ options, selected, onToggle }) => (
  <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
    {options.map((opt) => {
      const val = typeof opt === "object" ? opt.value : opt;
      const label = typeof opt === "object" ? opt.label : String(opt);
      const active = selected.includes(val);
      return (
        <TouchableOpacity
          key={String(val)}
          onPress={() => onToggle(val)}
          style={{
            paddingVertical: 8,
            paddingHorizontal: 14,
            borderRadius: 999,
            borderWidth: 1,
            borderColor: active ? "#2563EB" : "#E5E7EB",
            backgroundColor: active ? "#EFF6FF" : "#FFFFFF",
          }}
        >
          <Text
            style={{
              fontSize: 13,
              fontWeight: "500",
              color: active ? "#2563EB" : "#6B7280",
            }}
          >
            {label}
          </Text>
        </TouchableOpacity>
      );
    })}
  </View>
);

// ── Constants ────────────────────────────────────────────────────
const MAJOR_KEYS = [
  "C",
  "G",
  "D",
  "A",
  "E",
  "B",
  "F#",
  "F",
  "Bb",
  "Eb",
  "Ab",
  "Db",
];
const MINOR_KEYS = [
  { value: "A", label: "Am" },
  { value: "E", label: "Em" },
  { value: "B", label: "Bm" },
  { value: "F#", label: "F#m" },
  { value: "C#", label: "C#m" },
  { value: "G#", label: "G#m" },
  { value: "D#", label: "D#m" },
  { value: "D", label: "Dm" },
  { value: "G", label: "Gm" },
  { value: "C", label: "Cm" },
  { value: "F", label: "Fm" },
  { value: "Bb", label: "Bbm" },
];
const SCALE_DEGREES = [
  { value: 1, label: "1 · Tonic" },
  { value: 2, label: "2 · Supertonic" },
  { value: 3, label: "3 · Mediant" },
  { value: 4, label: "4 · Subdominant" },
  { value: 5, label: "5 · Dominant" },
  { value: 6, label: "6 · Submediant" },
  { value: 7, label: "7 · Leading Tone" },
];
const TIME_SIGNATURES = ["2/4", "3/4", "4/4", "5/4", "6/8", "12/8"];
const RHYTHM_PATTERNS = [
  "Quarter Notes",
  "Eighth Notes",
  "Half Notes",
  "Whole Notes",
  "Dotted Rhythms",
  "Triplets",
  "Syncopation",
];

// ── Main Screen ──────────────────────────────────────────────────
export default function PracticeScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();

  const [sessionType, setSessionType] = useState("pitch");
  const [mode, setMode] = useState("major");
  const [selectedMajorKeys, setSelectedMajorKeys] = useState(["C"]);
  const [selectedMinorKeys, setSelectedMinorKeys] = useState(["A"]);
  const [chordType, setChordType] = useState("tonic");
  const [startingDegrees, setStartingDegrees] = useState([1]);
  const [clef, setClef] = useState("treble");
  const [measures, setMeasures] = useState(4);
  const [allowedTimeSignatures, setAllowedTimeSignatures] = useState(["4/4"]);
  const [allowedRhythms, setAllowedRhythms] = useState(["Quarter Notes"]);
  const [difficulty, setDifficulty] = useState("medium");
  const [inputMode, setInputMode] = useState("microphone");
  const [attempts, setAttempts] = useState(3);
  const [strictness, setStrictness] = useState("medium");

  const toggle = (setter, current, val) => {
    if (current.includes(val)) {
      if (current.length === 1) return; // keep at least one selected
      setter(current.filter((v) => v !== val));
    } else {
      setter([...current, val]);
    }
  };

  const startSession = () => {
    const config = {
      sessionType,
      mode,
      selectedMajorKeys,
      selectedMinorKeys,
      chordType,
      startingDegrees,
      clef,
      measures,
      allowedTimeSignatures,
      allowedRhythms,
      difficulty,
      inputMode,
      attempts,
      strictness,
    };
    router.push({
      pathname: "/session",
      params: { config: JSON.stringify(config) },
    });
  };

  return (
    <View
      style={{ flex: 1, backgroundColor: "#F9FAFB", paddingTop: insets.top }}
    >
      <StatusBar style="dark" />

      {/* Header */}
      <View
        style={{
          paddingHorizontal: 20,
          paddingTop: 24,
          paddingBottom: 16,
          backgroundColor: "#FFFFFF",
          borderBottomWidth: 1,
          borderBottomColor: "#E5E7EB",
        }}
      >
        <Text
          style={{
            fontSize: 28,
            fontWeight: "600",
            color: "#111827",
            letterSpacing: -0.5,
          }}
        >
          Ear Training
        </Text>
        <Text style={{ fontSize: 14, color: "#6B7280", marginTop: 4 }}>
          Configure your practice session
        </Text>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ padding: 20, paddingBottom: 120 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Session Type */}
        <Card title="Session Type">
          <SingleSelect
            options={[
              { value: "pitch", label: "Pitch Recognition" },
              { value: "rhythm", label: "Rhythm Clapping" },
            ]}
            value={sessionType}
            onChange={setSessionType}
          />
        </Card>

        {/* Mode */}
        <Card title="Mode">
          <SingleSelect
            options={[
              { value: "major", label: "Major" },
              { value: "minor", label: "Minor" },
              { value: "random", label: "Random (either)" },
            ]}
            value={mode}
            onChange={setMode}
          />
        </Card>

        {/* Major Keys */}
        {(mode === "major" || mode === "random") && (
          <Card
            title="Major Keys"
            subtitle="Select one or more — computer picks randomly each session"
          >
            <MultiSelect
              options={MAJOR_KEYS}
              selected={selectedMajorKeys}
              onToggle={(val) =>
                toggle(setSelectedMajorKeys, selectedMajorKeys, val)
              }
            />
          </Card>
        )}

        {/* Minor Keys */}
        {(mode === "minor" || mode === "random") && (
          <Card
            title="Minor Keys"
            subtitle="Select one or more — computer picks randomly each session"
          >
            <MultiSelect
              options={MINOR_KEYS}
              selected={selectedMinorKeys}
              onToggle={(val) =>
                toggle(setSelectedMinorKeys, selectedMinorKeys, val)
              }
            />
          </Card>
        )}

        {/* Reference Chord */}
        <Card
          title="Reference Chord"
          subtitle="Played before the melody to set the tonal center"
        >
          <SingleSelect
            options={[
              { value: "none", label: "None" },
              { value: "tonic", label: "Tonic (I)" },
              { value: "dominant", label: "Dominant (V)" },
              { value: "random", label: "Random" },
            ]}
            value={chordType}
            onChange={setChordType}
          />
        </Card>

        {/* Melody Start Degree */}
        <Card
          title="Melody Start Degree"
          subtitle="Which scale degree the melody begins on (computer picks from your selection)"
        >
          <MultiSelect
            options={SCALE_DEGREES}
            selected={startingDegrees}
            onToggle={(val) => toggle(setStartingDegrees, startingDegrees, val)}
          />
        </Card>

        {/* Clef */}
        <Card title="Clef">
          <SingleSelect
            options={[
              { value: "treble", label: "𝄞  Treble Clef" },
              { value: "bass", label: "𝄢  Bass Clef" },
            ]}
            value={clef}
            onChange={setClef}
          />
        </Card>

        {/* Session Length in Measures */}
        <Card
          title="Session Length"
          subtitle="Number of measures in the melody"
        >
          <SingleSelect
            options={[2, 4, 8, 16].map((m) => ({
              value: m,
              label: `${m} bar${m > 1 ? "s" : ""}`,
            }))}
            value={measures}
            onChange={setMeasures}
          />
        </Card>

        {/* Time Signatures */}
        <Card
          title="Time Signatures"
          subtitle="Select one or more — computer picks randomly each session"
        >
          <MultiSelect
            options={TIME_SIGNATURES}
            selected={allowedTimeSignatures}
            onToggle={(val) =>
              toggle(setAllowedTimeSignatures, allowedTimeSignatures, val)
            }
          />
        </Card>

        {/* Rhythm Patterns */}
        <Card
          title="Rhythm Patterns"
          subtitle="Note durations allowed in the generated melody"
        >
          <MultiSelect
            options={RHYTHM_PATTERNS}
            selected={allowedRhythms}
            onToggle={(val) => toggle(setAllowedRhythms, allowedRhythms, val)}
          />
        </Card>

        {/* Input Mode */}
        <Card title="Input Mode" subtitle="How you respond to the melody">
          <SingleSelect
            options={[
              { value: "microphone", label: "🎤  Microphone" },
              { value: "keyboard", label: "🎹  Digital Keyboard" },
            ]}
            value={inputMode}
            onChange={setInputMode}
          />
        </Card>

        {/* Difficulty */}
        <Card title="Difficulty">
          <SingleSelect
            options={["easy", "medium", "hard"]}
            value={difficulty}
            onChange={setDifficulty}
          />
        </Card>

        {/* Attempts */}
        <Card title="Attempts per Session">
          <SingleSelect
            options={[1, 2, 3, 5].map((n) => ({ value: n, label: `${n}×` }))}
            value={attempts}
            onChange={setAttempts}
          />
        </Card>

        {/* Strictness */}
        <Card title="Grading Strictness">
          <SingleSelect
            options={[
              { value: "lenient", label: "Lenient" },
              { value: "medium", label: "Medium" },
              { value: "strict", label: "Strict" },
            ]}
            value={strictness}
            onChange={setStrictness}
          />
        </Card>
      </ScrollView>

      {/* Start Button */}
      <View
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          padding: 20,
          paddingBottom: insets.bottom + 20,
          backgroundColor: "#FFFFFF",
          borderTopWidth: 1,
          borderTopColor: "#E5E7EB",
        }}
      >
        <TouchableOpacity
          onPress={startSession}
          style={{
            backgroundColor: "#2563EB",
            borderRadius: 8,
            paddingVertical: 16,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
          }}
        >
          <Play color="#FFFFFF" size={20} fill="#FFFFFF" />
          <Text style={{ fontSize: 16, fontWeight: "600", color: "#FFFFFF" }}>
            Start Practice Session
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
