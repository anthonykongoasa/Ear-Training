import { View, Text, ScrollView, TouchableOpacity } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { Info, HelpCircle, Mail } from "lucide-react-native";

export default function SettingsScreen() {
  const insets = useSafeAreaInsets();

  return (
    <View
      style={{ flex: 1, backgroundColor: "#F9FAFB", paddingTop: insets.top }}
    >
      <StatusBar style="dark" />

      {/* Header */}
      <View
        style={{
          paddingHorizontal: 20,
          paddingTop: 24,
          paddingBottom: 16,
          backgroundColor: "#FFFFFF",
          borderBottomWidth: 1,
          borderBottomColor: "#E5E7EB",
        }}
      >
        <Text
          style={{
            fontSize: 28,
            fontWeight: "600",
            color: "#111827",
            letterSpacing: -0.5,
          }}
        >
          Settings
        </Text>
        <Text style={{ fontSize: 14, color: "#6B7280", marginTop: 4 }}>
          Manage your preferences
        </Text>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ padding: 20 }}
        showsVerticalScrollIndicator={false}
      >
        {/* About Section */}
        <View
          style={{
            backgroundColor: "#FFFFFF",
            borderRadius: 12,
            borderWidth: 1,
            borderColor: "#E5E7EB",
            marginBottom: 16,
          }}
        >
          <TouchableOpacity
            style={{
              flexDirection: "row",
              alignItems: "center",
              padding: 20,
              borderBottomWidth: 1,
              borderBottomColor: "#E5E7EB",
            }}
          >
            <Info color="#6B7280" size={20} />
            <Text
              style={{
                flex: 1,
                fontSize: 15,
                color: "#111827",
                marginLeft: 12,
              }}
            >
              About
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={{
              flexDirection: "row",
              alignItems: "center",
              padding: 20,
              borderBottomWidth: 1,
              borderBottomColor: "#E5E7EB",
            }}
          >
            <HelpCircle color="#6B7280" size={20} />
            <Text
              style={{
                flex: 1,
                fontSize: 15,
                color: "#111827",
                marginLeft: 12,
              }}
            >
              Help & Support
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={{
              flexDirection: "row",
              alignItems: "center",
              padding: 20,
            }}
          >
            <Mail color="#6B7280" size={20} />
            <Text
              style={{
                flex: 1,
                fontSize: 15,
                color: "#111827",
                marginLeft: 12,
              }}
            >
              Contact Us
            </Text>
          </TouchableOpacity>
        </View>

        {/* App Info */}
        <View
          style={{
            backgroundColor: "#FFFFFF",
            borderRadius: 12,
            borderWidth: 1,
            borderColor: "#E5E7EB",
            padding: 20,
          }}
        >
          <Text
            style={{
              fontSize: 16,
              fontWeight: "600",
              color: "#111827",
              marginBottom: 12,
            }}
          >
            App Information
          </Text>
          <View style={{ gap: 8 }}>
            <View
              style={{ flexDirection: "row", justifyContent: "space-between" }}
            >
              <Text style={{ fontSize: 14, color: "#6B7280" }}>Version</Text>
              <Text
                style={{ fontSize: 14, color: "#111827", fontWeight: "500" }}
              >
                1.0.0
              </Text>
            </View>
            <View
              style={{ flexDirection: "row", justifyContent: "space-between" }}
            >
              <Text style={{ fontSize: 14, color: "#6B7280" }}>Build</Text>
              <Text
                style={{ fontSize: 14, color: "#111827", fontWeight: "500" }}
              >
                100
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}
