import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { useState, useEffect } from "react";
import { useRouter, useLocalSearchParams } from "expo-router";
import { ArrowLeft, TrendingUp, Home } from "lucide-react-native";
import Svg, { Line, Ellipse, Text as SvgText, G, Rect } from "react-native-svg";

// ═══════════════════════════════════════════════════════════════
//  STAFF NOTATION HELPER
// ═══════════════════════════════════════════════════════════════
// Y positions for notes on the staff.
// Staff lines (bottom to top): line1=68, line2=56, line3=44, line4=32, line5=20
// Each step = 6px. STAFF_TOP offsets add this base.
const TREBLE_Y = {
  // ledger lines above
  A5: 2,
  G5: 8,
  F5: 14,
  // staff
  E5: 20,
  D5: 26,
  C5: 32,
  B4: 38,
  A4: 44,
  G4: 50,
  F4: 56,
  E4: 62,
  // ledger lines below
  D4: 68,
  C4: 74,
  B3: 80,
  A3: 86,
};
const BASS_Y = {
  // ledger lines above
  C4: 2,
  B3: 8,
  // staff
  A3: 14,
  G3: 20,
  F3: 26,
  E3: 32,
  D3: 38,
  C3: 44,
  B2: 50,
  A2: 56,
  // ledger lines below
  G2: 62,
  F2: 68,
  E2: 74,
  D2: 80,
};

const getNoteY = (noteStr, clef) => {
  const map = clef === "treble" ? TREBLE_Y : BASS_Y;
  if (map[noteStr] !== undefined) return map[noteStr];
  // strip accidentals and retry
  const name = noteStr.slice(0, -1).replace("#", "").replace("b", "");
  const octave = noteStr.slice(-1);
  const natural = name + octave;
  if (map[natural] !== undefined) return map[natural];
  return 38; // fallback to middle
};

// Is this note on a ledger line position (above or below staff)?
const needsLedgerLine = (y) => y <= 8 || y >= 68;
// Is note below the staff?
const isBelowStaff = (y) => y >= 68;
// Is note above the staff?
const isAboveStaff = (y) => y <= 8;

const STAFF_LINE_Y = [14, 26, 38, 50, 62]; // 5 staff lines within the 80px canvas

const StaffNotation = ({ notes, responses, clef }) => {
  const NOTE_GAP = 52;
  const LEFT_MARGIN = 48;
  const CANVAS_H = 110;
  const totalW = Math.max(notes.length * NOTE_GAP + LEFT_MARGIN + 24, 340);

  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={true}
      style={{ flexGrow: 0 }}
    >
      <Svg width={totalW} height={CANVAS_H}>
        {/* Staff background */}
        <Rect x={0} y={0} width={totalW} height={CANVAS_H} fill="#FAFAFA" />

        {/* Five staff lines */}
        {STAFF_LINE_Y.map((y, i) => (
          <Line
            key={i}
            x1={8}
            y1={y + 14}
            x2={totalW - 8}
            y2={y + 14}
            stroke="#CBD5E1"
            strokeWidth="1"
          />
        ))}

        {/* Clef symbol */}
        <SvgText
          x={10}
          y={clef === "treble" ? 68 : 52}
          fontSize={clef === "treble" ? 52 : 40}
          fill="#374151"
        >
          {clef === "treble" ? "𝄞" : "𝄢"}
        </SvgText>

        {/* Notes */}
        {notes.map((note, idx) => {
          const x = LEFT_MARGIN + idx * NOTE_GAP;
          const rawY = getNoteY(note, clef);
          const y = rawY + 14; // shift down by top margin
          const resp = responses[idx];
          const isCorrect = resp && resp.expected === resp.actual;
          const noteColor = resp
            ? isCorrect
              ? "#10B981"
              : "#EF4444"
            : "#2563EB";

          return (
            <G key={idx}>
              {/* Ledger lines */}
              {rawY <= 8 && (
                <Line
                  x1={x - 10}
                  y1={y}
                  x2={x + 22}
                  y2={y}
                  stroke="#94A3B8"
                  strokeWidth="1.5"
                />
              )}
              {rawY >= 68 && (
                <Line
                  x1={x - 10}
                  y1={y}
                  x2={x + 22}
                  y2={y}
                  stroke="#94A3B8"
                  strokeWidth="1.5"
                />
              )}
              {/* Middle C ledger line (treble C4 at y=74, bass C4 at y=16) */}
              {clef === "treble" && rawY === 74 && (
                <Line
                  x1={x - 10}
                  y1={y}
                  x2={x + 22}
                  y2={y}
                  stroke="#94A3B8"
                  strokeWidth="1.5"
                />
              )}

              {/* Note head */}
              <Ellipse cx={x + 7} cy={y} rx={8} ry={5.5} fill={noteColor} />

              {/* Stem */}
              <Line
                x1={x + 15}
                y1={y}
                x2={x + 15}
                y2={y - 30}
                stroke={noteColor}
                strokeWidth="1.5"
              />

              {/* Note name below */}
              <SvgText
                x={x - 2}
                y={CANVAS_H - 4}
                fontSize={9}
                fill={noteColor}
                fontWeight="600"
              >
                {note.slice(0, -1)}
              </SvgText>

              {/* Measure bar — every N notes based on beats per measure would be ideal;
                  for simplicity add a visual separator every 4 notes */}
              {idx > 0 && idx % 4 === 0 && (
                <Line
                  x1={x - 6}
                  y1={14 + 14}
                  x2={x - 6}
                  y2={14 + 62}
                  stroke="#D1D5DB"
                  strokeWidth="1"
                />
              )}
            </G>
          );
        })}

        {/* Final barline */}
        <Line
          x1={totalW - 10}
          y1={14 + 14}
          x2={totalW - 10}
          y2={14 + 62}
          stroke="#374151"
          strokeWidth="2"
        />
      </Svg>
    </ScrollView>
  );
};

// ═══════════════════════════════════════════════════════════════
//  RESULTS SCREEN
// ═══════════════════════════════════════════════════════════════
export default function ResultsScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const {
    notesPlayed,
    userResponses,
    score,
    accuracy,
    settings,
    sessionKey,
    sessionMode,
    timeSig,
  } = useLocalSearchParams();

  let notes = [],
    responses = [],
    config = {};
  try {
    notes = JSON.parse(notesPlayed);
  } catch {}
  try {
    responses = JSON.parse(userResponses);
  } catch {}
  try {
    config = JSON.parse(settings);
  } catch {}

  const [aiFeedback, setAiFeedback] = useState(null);
  const [loadingFeedback, setLoadingFeedback] = useState(true);

  useEffect(() => {
    fetchAIFeedback();
    saveSession();
  }, []);

  const fetchAIFeedback = async () => {
    try {
      const res = await fetch("/api/sessions/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          notesPlayed: notes,
          userResponses: responses,
          score: parseInt(score),
          accuracy: parseFloat(accuracy),
          settings: config,
          sessionKey,
          sessionMode,
          timeSig,
        }),
      });
      if (!res.ok) throw new Error("failed");
      const data = await res.json();
      setAiFeedback(data.feedback);
    } catch {
      setAiFeedback(
        "Keep at it! Try singing the scale first to internalize the tonal center before playing back the melody.",
      );
    } finally {
      setLoadingFeedback(false);
    }
  };

  const saveSession = async () => {
    try {
      await fetch("/api/sessions/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sessionType: config.sessionType || "pitch",
          score: parseInt(score),
          accuracyPercentage: parseFloat(accuracy),
          notesPlayed: notes,
          userResponses: responses,
          settings: config,
        }),
      });
    } catch (err) {
      console.error("saveSession error", err);
    }
  };

  const getScoreColor = () => {
    if (score >= 80) return "#10B981";
    if (score >= 60) return "#F59E0B";
    return "#EF4444";
  };

  const correctCount = responses.filter(
    (r) => r && r.expected === r.actual,
  ).length;
  const clef = config.clef || "treble";
  const scoreNum = parseInt(score) || 0;
  const circumference = 377;

  return (
    <View
      style={{ flex: 1, backgroundColor: "#F9FAFB", paddingTop: insets.top }}
    >
      <StatusBar style="dark" />

      {/* Header */}
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          paddingHorizontal: 20,
          paddingVertical: 16,
          backgroundColor: "#FFFFFF",
          borderBottomWidth: 1,
          borderBottomColor: "#E5E7EB",
        }}
      >
        <TouchableOpacity
          onPress={() => router.back()}
          style={{ marginRight: 16 }}
        >
          <ArrowLeft color="#111827" size={24} />
        </TouchableOpacity>
        <Text style={{ fontSize: 18, fontWeight: "600", color: "#111827" }}>
          Session Results
        </Text>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ padding: 20, paddingBottom: 120 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Key Banner */}
        <View
          style={{
            backgroundColor: "#111827",
            borderRadius: 12,
            padding: 20,
            marginBottom: 16,
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <View>
            <Text
              style={{
                fontSize: 11,
                color: "#6B7280",
                textTransform: "uppercase",
                letterSpacing: 1.5,
              }}
            >
              Session Key
            </Text>
            <Text
              style={{
                fontSize: 34,
                fontWeight: "700",
                color: "#FFFFFF",
                marginTop: 4,
              }}
            >
              {sessionKey || "—"}{" "}
              <Text
                style={{
                  fontSize: 18,
                  color: "#9CA3AF",
                  textTransform: "capitalize",
                }}
              >
                {sessionMode || ""}
              </Text>
            </Text>
          </View>
          <View style={{ alignItems: "flex-end", gap: 4 }}>
            <View
              style={{
                paddingHorizontal: 10,
                paddingVertical: 4,
                borderRadius: 999,
                backgroundColor: "#1F2937",
                borderWidth: 1,
                borderColor: "#374151",
              }}
            >
              <Text style={{ fontSize: 12, color: "#9CA3AF" }}>
                {timeSig || "4/4"}
              </Text>
            </View>
            <View
              style={{
                paddingHorizontal: 10,
                paddingVertical: 4,
                borderRadius: 999,
                backgroundColor: "#1F2937",
                borderWidth: 1,
                borderColor: "#374151",
              }}
            >
              <Text style={{ fontSize: 12, color: "#9CA3AF" }}>
                {clef === "treble" ? "𝄞 Treble" : "𝄢 Bass"}
              </Text>
            </View>
            <View
              style={{
                paddingHorizontal: 10,
                paddingVertical: 4,
                borderRadius: 999,
                backgroundColor: "#1F2937",
                borderWidth: 1,
                borderColor: "#374151",
              }}
            >
              <Text style={{ fontSize: 12, color: "#9CA3AF" }}>
                {notes.length} notes
              </Text>
            </View>
          </View>
        </View>

        {/* Score Card */}
        <View
          style={{
            backgroundColor: "#FFFFFF",
            borderRadius: 12,
            borderWidth: 1,
            borderColor: "#E5E7EB",
            padding: 24,
            marginBottom: 16,
            alignItems: "center",
          }}
        >
          <View
            style={{
              width: 140,
              height: 140,
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <Svg width={140} height={140} style={{ position: "absolute" }}>
              <Ellipse
                cx={70}
                cy={70}
                rx={60}
                ry={60}
                stroke="#E5E7EB"
                strokeWidth={12}
                fill="none"
              />
              <Ellipse
                cx={70}
                cy={70}
                rx={60}
                ry={60}
                stroke={getScoreColor()}
                strokeWidth={12}
                fill="none"
                strokeDasharray={`${(scoreNum / 100) * circumference} ${circumference}`}
                strokeLinecap="round"
                transform="rotate(-90 70 70)"
              />
            </Svg>
            <Text style={{ fontSize: 38, fontWeight: "700", color: "#111827" }}>
              {scoreNum}%
            </Text>
            <Text style={{ fontSize: 12, color: "#6B7280" }}>Score</Text>
          </View>

          <View
            style={{
              flexDirection: "row",
              gap: 0,
              marginTop: 16,
              borderWidth: 1,
              borderColor: "#E5E7EB",
              borderRadius: 8,
              overflow: "hidden",
            }}
          >
            {[
              { label: "Correct", value: correctCount, color: "#10B981" },
              {
                label: "Missed",
                value: notes.length - correctCount,
                color: "#EF4444",
              },
              { label: "Total", value: notes.length, color: "#111827" },
            ].map((item, i) => (
              <View
                key={i}
                style={{
                  flex: 1,
                  paddingVertical: 14,
                  alignItems: "center",
                  borderLeftWidth: i > 0 ? 1 : 0,
                  borderLeftColor: "#E5E7EB",
                }}
              >
                <Text
                  style={{ fontSize: 22, fontWeight: "600", color: item.color }}
                >
                  {item.value}
                </Text>
                <Text style={{ fontSize: 12, color: "#6B7280", marginTop: 2 }}>
                  {item.label}
                </Text>
              </View>
            ))}
          </View>
        </View>

        {/* Staff Notation — full melody */}
        <View
          style={{
            backgroundColor: "#FFFFFF",
            borderRadius: 12,
            borderWidth: 1,
            borderColor: "#E5E7EB",
            padding: 20,
            marginBottom: 16,
          }}
        >
          <Text
            style={{
              fontSize: 16,
              fontWeight: "600",
              color: "#111827",
              marginBottom: 2,
            }}
          >
            {clef === "treble" ? "𝄞 Treble" : "𝄢 Bass"} Clef — Full Melody
          </Text>
          <Text style={{ fontSize: 12, color: "#9CA3AF", marginBottom: 16 }}>
            Green = matched · Red = missed · Blue = unscored
          </Text>
          {notes.length > 0 ? (
            <StaffNotation notes={notes} responses={responses} clef={clef} />
          ) : (
            <Text style={{ color: "#9CA3AF", fontSize: 14 }}>
              No notes to display
            </Text>
          )}
        </View>

        {/* Note-by-Note Breakdown */}
        <View
          style={{
            backgroundColor: "#FFFFFF",
            borderRadius: 12,
            borderWidth: 1,
            borderColor: "#E5E7EB",
            padding: 20,
            marginBottom: 16,
          }}
        >
          <Text
            style={{
              fontSize: 16,
              fontWeight: "600",
              color: "#111827",
              marginBottom: 16,
            }}
          >
            Note Breakdown
          </Text>
          {responses.length === 0 && (
            <Text style={{ color: "#9CA3AF", fontSize: 14 }}>
              No responses recorded.
            </Text>
          )}
          {responses.map((resp, i) => {
            if (!resp) return null;
            const correct = resp.expected === resp.actual;
            return (
              <View
                key={i}
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  paddingVertical: 10,
                  borderBottomWidth: i < responses.length - 1 ? 1 : 0,
                  borderBottomColor: "#F3F4F6",
                }}
              >
                <View
                  style={{
                    width: 30,
                    height: 30,
                    borderRadius: 999,
                    marginRight: 12,
                    backgroundColor: correct ? "#D1FAE5" : "#FEE2E2",
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <Text
                    style={{
                      fontSize: 12,
                      fontWeight: "700",
                      color: correct ? "#059669" : "#DC2626",
                    }}
                  >
                    {i + 1}
                  </Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text
                    style={{
                      fontSize: 14,
                      fontWeight: "500",
                      color: "#111827",
                    }}
                  >
                    Expected:{" "}
                    <Text style={{ color: "#2563EB", fontWeight: "600" }}>
                      {resp.expected}
                    </Text>
                  </Text>
                  <Text
                    style={{ fontSize: 12, color: "#6B7280", marginTop: 2 }}
                  >
                    Played:{" "}
                    <Text
                      style={{
                        color: correct ? "#059669" : "#DC2626",
                        fontWeight: "500",
                      }}
                    >
                      {resp.actual || "—"}
                    </Text>
                  </Text>
                </View>
                <View
                  style={{
                    width: 28,
                    height: 28,
                    borderRadius: 999,
                    backgroundColor: correct ? "#D1FAE5" : "#FEE2E2",
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <Text
                    style={{
                      fontSize: 14,
                      color: correct ? "#059669" : "#DC2626",
                      fontWeight: "700",
                    }}
                  >
                    {correct ? "✓" : "✗"}
                  </Text>
                </View>
              </View>
            );
          })}
        </View>

        {/* AI Feedback */}
        <View
          style={{
            backgroundColor: "#FFFFFF",
            borderRadius: 12,
            borderWidth: 1,
            borderColor: "#E5E7EB",
            padding: 20,
            marginBottom: 16,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              marginBottom: 12,
            }}
          >
            <TrendingUp color="#2563EB" size={20} />
            <Text
              style={{
                fontSize: 16,
                fontWeight: "600",
                color: "#111827",
                marginLeft: 8,
              }}
            >
              AI Feedback
            </Text>
          </View>
          {loadingFeedback ? (
            <View style={{ paddingVertical: 20, alignItems: "center" }}>
              <ActivityIndicator size="small" color="#2563EB" />
              <Text style={{ fontSize: 13, color: "#6B7280", marginTop: 8 }}>
                Analyzing your performance…
              </Text>
            </View>
          ) : (
            <Text style={{ fontSize: 14, color: "#374151", lineHeight: 22 }}>
              {aiFeedback}
            </Text>
          )}
        </View>
      </ScrollView>

      {/* Bottom Button */}
      <View
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          padding: 20,
          paddingBottom: insets.bottom + 20,
          backgroundColor: "#FFFFFF",
          borderTopWidth: 1,
          borderTopColor: "#E5E7EB",
        }}
      >
        <TouchableOpacity
          onPress={() => router.push("/(tabs)")}
          style={{
            backgroundColor: "#2563EB",
            borderRadius: 8,
            paddingVertical: 16,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
          }}
        >
          <Home color="#FFFFFF" size={20} />
          <Text style={{ fontSize: 16, fontWeight: "600", color: "#FFFFFF" }}>
            Back to Practice
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
