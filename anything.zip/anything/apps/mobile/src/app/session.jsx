import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { useState, useEffect, useRef } from "react";
import { useRouter, useLocalSearchParams } from "expo-router";
import {
  ArrowLeft,
  Volume2,
  Mic,
  ChevronRight,
  RotateCcw,
} from "lucide-react-native";
import { Audio } from "expo-av";

// ═══════════════════════════════════════════════════════════════
//  MUSIC THEORY
// ═══════════════════════════════════════════════════════════════
const CHROMA = {
  C: 0,
  "C#": 1,
  Db: 1,
  D: 2,
  "D#": 3,
  Eb: 3,
  E: 4,
  Fb: 4,
  F: 5,
  "E#": 5,
  "F#": 6,
  Gb: 6,
  G: 7,
  "G#": 8,
  Ab: 8,
  A: 9,
  "A#": 10,
  Bb: 10,
  B: 11,
  Cb: 11,
};

const MAJOR_SCALES = {
  C: ["C", "D", "E", "F", "G", "A", "B"],
  G: ["G", "A", "B", "C", "D", "E", "F#"],
  D: ["D", "E", "F#", "G", "A", "B", "C#"],
  A: ["A", "B", "C#", "D", "E", "F#", "G#"],
  E: ["E", "F#", "G#", "A", "B", "C#", "D#"],
  B: ["B", "C#", "D#", "E", "F#", "G#", "A#"],
  "F#": ["F#", "G#", "A#", "B", "C#", "D#", "E#"],
  F: ["F", "G", "A", "Bb", "C", "D", "E"],
  Bb: ["Bb", "C", "D", "Eb", "F", "G", "A"],
  Eb: ["Eb", "F", "G", "Ab", "Bb", "C", "D"],
  Ab: ["Ab", "Bb", "C", "Db", "Eb", "F", "G"],
  Db: ["Db", "Eb", "F", "Gb", "Ab", "Bb", "C"],
};
const MINOR_SCALES = {
  A: ["A", "B", "C", "D", "E", "F", "G"],
  E: ["E", "F#", "G", "A", "B", "C", "D"],
  B: ["B", "C#", "D", "E", "F#", "G", "A"],
  "F#": ["F#", "G#", "A", "B", "C#", "D", "E"],
  "C#": ["C#", "D#", "E", "F#", "G#", "A", "B"],
  "G#": ["G#", "A#", "B", "C#", "D#", "E", "F#"],
  "D#": ["D#", "E#", "F#", "G#", "A#", "B", "C#"],
  D: ["D", "E", "F", "G", "A", "Bb", "C"],
  G: ["G", "A", "Bb", "C", "D", "Eb", "F"],
  C: ["C", "D", "Eb", "F", "G", "Ab", "Bb"],
  F: ["F", "G", "Ab", "Bb", "C", "Db", "Eb"],
  Bb: ["Bb", "C", "Db", "Eb", "F", "Gb", "Ab"],
};

// Build scale notes with proper octave assignments
const buildScale = (key, mode, baseOctave) => {
  const noteNames = mode === "major" ? MAJOR_SCALES[key] : MINOR_SCALES[key];
  if (!noteNames) return [];
  const result = [];
  let octave = baseOctave;
  let prevVal = -1;
  for (const name of noteNames) {
    const val = CHROMA[name] ?? 0;
    if (prevVal >= 0 && val <= prevVal) octave++;
    result.push({ name, octave, str: name + octave });
    prevVal = val;
  }
  // add the octave root
  const first = result[0];
  result.push({
    name: first.name,
    octave: first.octave + 1,
    str: first.name + (first.octave + 1),
  });
  // second octave
  for (let i = 0; i < noteNames.length; i++) {
    result.push({
      name: result[i].name,
      octave: result[i].octave + 1,
      str: result[i].name + (result[i].octave + 1),
    });
  }
  return result;
};

const noteToFreq = (name, octave) => {
  const val = CHROMA[name] ?? 0;
  const midi = (octave + 1) * 12 + val;
  return 440 * Math.pow(2, (midi - 69) / 12);
};

const getRhythmDurations = (rhythms) => {
  const all = [
    { name: "whole", beats: 4 },
    { name: "half", beats: 2 },
    { name: "dotted-half", beats: 3 },
    { name: "quarter", beats: 1 },
    { name: "dotted-quarter", beats: 1.5 },
    { name: "eighth", beats: 0.5 },
  ];
  if (!rhythms || rhythms.length === 0)
    return all.filter((d) => d.name === "quarter");
  return all.filter((d) => {
    if (rhythms.includes("Quarter Notes") && d.name === "quarter") return true;
    if (rhythms.includes("Eighth Notes") && d.name === "eighth") return true;
    if (
      rhythms.includes("Half Notes") &&
      (d.name === "half" || d.name === "dotted-half")
    )
      return true;
    if (rhythms.includes("Whole Notes") && d.name === "whole") return true;
    if (rhythms.includes("Dotted Rhythms") && d.name.includes("dotted"))
      return true;
    if (
      rhythms.includes("Syncopation") &&
      (d.name === "eighth" || d.name === "dotted-quarter")
    )
      return true;
    return false;
  });
};

// ═══════════════════════════════════════════════════════════════
//  WEB AUDIO (works in the web preview)
// ═══════════════════════════════════════════════════════════════
let _ctx = null;
const getCtx = () => {
  if (Platform.OS !== "web") return null;
  if (!_ctx) _ctx = new (window.AudioContext || window.webkitAudioContext)();
  if (_ctx.state === "suspended") _ctx.resume();
  return _ctx;
};

const playTone = (freq, durationMs, vol = 0.35) => {
  const ctx = getCtx();
  if (!ctx) return new Promise((r) => setTimeout(r, durationMs));
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.type = "sine";
  osc.frequency.setValueAtTime(freq, ctx.currentTime);
  gain.gain.setValueAtTime(0, ctx.currentTime);
  gain.gain.linearRampToValueAtTime(vol, ctx.currentTime + 0.02);
  gain.gain.exponentialRampToValueAtTime(
    0.001,
    ctx.currentTime + durationMs / 1000,
  );
  osc.start(ctx.currentTime);
  osc.stop(ctx.currentTime + durationMs / 1000);
  return new Promise((r) => setTimeout(r, durationMs));
};

const playChord = (freqs, durationMs) => {
  const ctx = getCtx();
  if (!ctx) return new Promise((r) => setTimeout(r, durationMs));
  freqs.forEach((freq) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.type = "sine";
    osc.frequency.setValueAtTime(freq, ctx.currentTime);
    gain.gain.setValueAtTime(0, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.22, ctx.currentTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(
      0.001,
      ctx.currentTime + durationMs / 1000,
    );
    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + durationMs / 1000);
  });
  return new Promise((r) => setTimeout(r, durationMs));
};

// ═══════════════════════════════════════════════════════════════
//  DIGITAL PIANO KEYBOARD COMPONENT
// ═══════════════════════════════════════════════════════════════
const WHITE_NOTES = ["C", "D", "E", "F", "G", "A", "B"];
// left offsets for black keys within one octave (null = no black key)
const BLACK_OFFSETS = [30, 74, null, 162, 206, 250, null];
const WW = 44; // white key width
const WH = 120; // white key height
const BW = 28; // black key width
const BH = 74; // black key height
const OCT_W = WW * 7; // 308

const PianoKeyboard = ({ onNotePress, userNotes, totalExpected, clef }) => {
  const octaves = clef === "treble" ? [4, 5] : [2, 3];
  return (
    <ScrollView
      horizontal
      showsHorizontalScrollIndicator={false}
      style={{ flexGrow: 0 }}
      contentContainerStyle={{ paddingVertical: 8 }}
    >
      {octaves.map((oct) => (
        <View
          key={oct}
          style={{ width: OCT_W, position: "relative", marginRight: 2 }}
        >
          {/* White keys */}
          <View style={{ flexDirection: "row" }}>
            {WHITE_NOTES.map((note) => {
              const noteStr = note + oct;
              const timesPressed = userNotes.filter(
                (n) => n === noteStr,
              ).length;
              const isPressed = timesPressed > 0;
              return (
                <TouchableOpacity
                  key={note}
                  onPress={() => onNotePress(noteStr)}
                  style={{
                    width: WW - 1,
                    height: WH,
                    marginRight: 1,
                    backgroundColor: isPressed ? "#DBEAFE" : "#FFFFFF",
                    borderWidth: 1,
                    borderColor: "#D1D5DB",
                    justifyContent: "flex-end",
                    alignItems: "center",
                    paddingBottom: 8,
                    borderRadius: 4,
                  }}
                >
                  <Text
                    style={{
                      fontSize: 10,
                      color: isPressed ? "#2563EB" : "#9CA3AF",
                      fontWeight: isPressed ? "600" : "400",
                    }}
                  >
                    {note}
                    {oct}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
          {/* Black keys */}
          {BLACK_OFFSETS.map((offset, i) => {
            if (offset === null) return null;
            const sharpNames = ["C#", "D#", null, "F#", "G#", "A#", null];
            const noteName = sharpNames[i];
            if (!noteName) return null;
            const noteStr = noteName + oct;
            const isPressed = userNotes.includes(noteStr);
            return (
              <TouchableOpacity
                key={noteName}
                onPress={() => onNotePress(noteStr)}
                style={{
                  position: "absolute",
                  top: 0,
                  left: offset,
                  width: BW,
                  height: BH,
                  backgroundColor: isPressed ? "#3B82F6" : "#1F2937",
                  borderRadius: 4,
                  zIndex: 10,
                  justifyContent: "flex-end",
                  alignItems: "center",
                  paddingBottom: 6,
                }}
              >
                {isPressed && (
                  <Text style={{ fontSize: 7, color: "#BFDBFE" }}>
                    {noteName}
                    {oct}
                  </Text>
                )}
              </TouchableOpacity>
            );
          })}
        </View>
      ))}
    </ScrollView>
  );
};

// ═══════════════════════════════════════════════════════════════
//  MAIN SCREEN
// ═══════════════════════════════════════════════════════════════
const DEFAULT_SETTINGS = {
  sessionType: "pitch",
  mode: "major",
  selectedMajorKeys: ["C"],
  selectedMinorKeys: ["A"],
  chordType: "tonic",
  startingDegrees: [1],
  clef: "treble",
  measures: 4,
  allowedTimeSignatures: ["4/4"],
  allowedRhythms: ["Quarter Notes"],
  difficulty: "medium",
  inputMode: "microphone",
  attempts: 3,
  strictness: "medium",
};

export default function SessionScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { config } = useLocalSearchParams();

  let settings = DEFAULT_SETTINGS;
  try {
    if (config) settings = { ...DEFAULT_SETTINGS, ...JSON.parse(config) };
  } catch {}

  // Session state
  const [sessionKey, setSessionKey] = useState(null);
  const [sessionMode, setSessionMode] = useState(null);
  const [timeSig, setTimeSig] = useState("4/4");
  const [melody, setMelody] = useState([]); // [{name, octave, str, duration, beats}]
  const [phase, setPhase] = useState("listen"); // "listen" | "respond"
  const [chordPlayed, setChordPlayed] = useState(false);
  const [melodyPlayed, setMelodyPlayed] = useState(false);
  const [isPlayingChord, setIsPlayingChord] = useState(false);
  const [isPlayingMelody, setIsPlayingMelody] = useState(false);
  const [userNotes, setUserNotes] = useState([]);
  const [isRecording, setIsRecording] = useState(false);
  const [attemptsLeft, setAttemptsLeft] = useState(settings.attempts);
  const recordingRef = useRef(null);

  useEffect(() => {
    generateSession();
    if (Platform.OS !== "web") {
      Audio.requestPermissionsAsync().then(() =>
        Audio.setAudioModeAsync({
          allowsRecordingIOS: true,
          playsInSilentModeIOS: true,
        }),
      );
    }
    return () => {
      if (recordingRef.current) recordingRef.current.stopAndUnloadAsync();
    };
  }, []);

  // ── Generate Key, Mode, TimeSig, Melody ──────────────────────
  const generateSession = () => {
    let chosenMode = settings.mode;
    if (chosenMode === "random")
      chosenMode = Math.random() < 0.5 ? "major" : "minor";

    const keyPool =
      chosenMode === "major"
        ? settings.selectedMajorKeys?.length
          ? settings.selectedMajorKeys
          : ["C"]
        : settings.selectedMinorKeys?.length
          ? settings.selectedMinorKeys
          : ["A"];
    const chosenKey = keyPool[Math.floor(Math.random() * keyPool.length)];

    const timeSigPool = settings.allowedTimeSignatures?.length
      ? settings.allowedTimeSignatures
      : ["4/4"];
    const chosenTimeSig =
      timeSigPool[Math.floor(Math.random() * timeSigPool.length)];

    const baseOctave = settings.clef === "treble" ? 4 : 2;
    const scale = buildScale(chosenKey, chosenMode, baseOctave);
    if (!scale.length) {
      setSessionKey(chosenKey);
      setSessionMode(chosenMode);
      setTimeSig(chosenTimeSig);
      setMelody([]);
      return;
    }

    const [beatsPerMeasure] = chosenTimeSig.split("/").map(Number);
    const totalBeats = (settings.measures || 4) * beatsPerMeasure;
    const durations = getRhythmDurations(settings.allowedRhythms);

    // Pick starting scale degree
    const degPool = settings.startingDegrees?.length
      ? settings.startingDegrees
      : [1];
    const startDeg = degPool[Math.floor(Math.random() * degPool.length)] - 1;

    const generated = [];
    let scaleIdx = Math.min(startDeg, scale.length - 1);
    let beatsLeft = totalBeats;

    while (beatsLeft > 0.01) {
      const avail = durations.filter((d) => d.beats <= beatsLeft + 0.01);
      if (!avail.length) break;
      const dur = avail[Math.floor(Math.random() * avail.length)];
      const steps = [-2, -1, 0, 1, 2, 3];
      const step = steps[Math.floor(Math.random() * steps.length)];
      scaleIdx = Math.max(0, Math.min(scale.length - 1, scaleIdx + step));
      generated.push({
        ...scale[scaleIdx],
        duration: dur.name,
        beats: dur.beats,
      });
      beatsLeft -= dur.beats;
    }

    setSessionKey(chosenKey);
    setSessionMode(chosenMode);
    setTimeSig(chosenTimeSig);
    setMelody(generated);
  };

  // ── Chord Frequencies ─────────────────────────────────────────
  const getChordFreqs = () => {
    const baseOctave = settings.clef === "treble" ? 4 : 2;
    const scale = buildScale(sessionKey, sessionMode, baseOctave);
    if (!scale.length) return [];
    let rootIdx = 0;
    if (settings.chordType === "dominant") rootIdx = 4;
    else if (settings.chordType === "random")
      rootIdx = [0, 3, 4][Math.floor(Math.random() * 3)];
    const triad = [
      scale[rootIdx % scale.length],
      scale[(rootIdx + 2) % scale.length],
      scale[(rootIdx + 4) % scale.length],
    ];
    return triad.map((n) => noteToFreq(n.name, n.octave));
  };

  // ── Playback Handlers ─────────────────────────────────────────
  const handlePlayChord = async () => {
    if (isPlayingChord || isPlayingMelody || settings.chordType === "none")
      return;
    setIsPlayingChord(true);
    setChordPlayed(true);
    const freqs = getChordFreqs();
    if (freqs.length) await playChord(freqs, 1600);
    else await new Promise((r) => setTimeout(r, 800));
    setIsPlayingChord(false);
  };

  const handlePlayMelody = async () => {
    if (isPlayingMelody || isPlayingChord) return;
    setIsPlayingMelody(true);
    setMelodyPlayed(true);
    const beatMs = 550; // quarter note duration in ms
    for (const note of melody) {
      const freq = noteToFreq(note.name, note.octave);
      const dur = note.beats * beatMs;
      await playTone(freq, dur * 0.85);
      await new Promise((r) => setTimeout(r, dur * 0.15));
    }
    setIsPlayingMelody(false);
  };

  // ── Digital Keyboard Handler ──────────────────────────────────
  const handleKeyPress = (noteStr) => {
    if (phase !== "respond") return;
    const name = noteStr.slice(0, -1);
    const octave = parseInt(noteStr.slice(-1));
    playTone(noteToFreq(name, octave), 300, 0.3);
    const updated = [...userNotes, noteStr];
    setUserNotes(updated);
    if (updated.length >= melody.length) completeSession(updated);
  };

  const handleClearLast = () => setUserNotes((prev) => prev.slice(0, -1));

  // ── Microphone Recording ──────────────────────────────────────
  const startRecording = async () => {
    if (Platform.OS === "web") {
      // Simulate on web
      setIsRecording(true);
      return;
    }
    try {
      setIsRecording(true);
      const { recording } = await Audio.Recording.createAsync(
        Audio.RecordingOptionsPresets.HIGH_QUALITY,
      );
      recordingRef.current = recording;
    } catch (err) {
      console.error("startRecording error", err);
      setIsRecording(false);
    }
  };

  const stopRecording = async () => {
    setIsRecording(false);
    if (recordingRef.current) {
      try {
        await recordingRef.current.stopAndUnloadAsync();
        recordingRef.current = null;
      } catch {}
    }
    // Simulate pitch detection per note
    const detected = melody.map((note) => {
      const chance =
        settings.strictness === "lenient"
          ? 0.75
          : settings.strictness === "medium"
            ? 0.55
            : 0.35;
      if (Math.random() < chance) return note.str;
      const pool = ["C4", "D4", "E4", "F4", "G4", "A4", "B4", "C5", "D5", "E5"];
      return pool[Math.floor(Math.random() * pool.length)];
    });
    completeSession(detected);
  };

  // ── Retry ─────────────────────────────────────────────────────
  const retrySession = () => {
    if (attemptsLeft <= 1) return;
    setAttemptsLeft((a) => a - 1);
    setUserNotes([]);
    setChordPlayed(false);
    setMelodyPlayed(false);
    setPhase("listen");
  };

  // ── Complete + Score ──────────────────────────────────────────
  const completeSession = (notes) => {
    const melodyStrs = melody.map((m) => m.str);
    let correct = 0;
    const len = Math.min(notes.length, melodyStrs.length);
    for (let i = 0; i < len; i++) {
      const exp = melodyStrs[i];
      const act = notes[i];
      if (settings.strictness === "strict") {
        if (exp === act) correct++;
      } else if (settings.strictness === "medium") {
        if (exp.slice(0, -1) === act?.slice(0, -1)) correct++;
      } else {
        const ev = CHROMA[exp.slice(0, -1)] ?? 0;
        const av = CHROMA[act?.slice(0, -1)] ?? 0;
        if (Math.abs(ev - av) <= 1) correct++;
      }
    }
    const accuracy = melody.length > 0 ? (correct / melody.length) * 100 : 0;
    const responses = melodyStrs.map((expected, i) => ({
      expected,
      actual: notes[i] || null,
      correct: notes[i] === expected,
    }));
    router.replace({
      pathname: "/results",
      params: {
        notesPlayed: JSON.stringify(melodyStrs),
        userResponses: JSON.stringify(responses),
        score: Math.round(accuracy),
        accuracy: accuracy.toFixed(2),
        settings: config || JSON.stringify(settings),
        sessionKey,
        sessionMode,
        timeSig,
      },
    });
  };

  const isLoading = !sessionKey;
  const isKeyboard = settings.inputMode === "keyboard";

  // ── RENDER ────────────────────────────────────────────────────
  return (
    <View
      style={{ flex: 1, backgroundColor: "#F9FAFB", paddingTop: insets.top }}
    >
      <StatusBar style="dark" />

      {/* Header */}
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          paddingHorizontal: 20,
          paddingVertical: 16,
          backgroundColor: "#FFFFFF",
          borderBottomWidth: 1,
          borderBottomColor: "#E5E7EB",
        }}
      >
        <TouchableOpacity
          onPress={() => router.back()}
          style={{ marginRight: 16 }}
        >
          <ArrowLeft color="#111827" size={24} />
        </TouchableOpacity>
        <View style={{ flex: 1 }}>
          <Text style={{ fontSize: 18, fontWeight: "600", color: "#111827" }}>
            Practice Session
          </Text>
          <Text style={{ fontSize: 13, color: "#6B7280", marginTop: 2 }}>
            {isLoading
              ? "Generating…"
              : `${sessionKey} ${sessionMode} · ${timeSig} · ${settings.measures} bar${settings.measures > 1 ? "s" : ""}`}
          </Text>
        </View>
        <View
          style={{
            paddingHorizontal: 10,
            paddingVertical: 4,
            borderRadius: 999,
            backgroundColor: "#EFF6FF",
            borderWidth: 1,
            borderColor: "#2563EB",
          }}
        >
          <Text
            style={{
              fontSize: 12,
              fontWeight: "500",
              color: "#2563EB",
              textTransform: "capitalize",
            }}
          >
            {settings.difficulty}
          </Text>
        </View>
      </View>

      {isLoading ? (
        <View
          style={{ flex: 1, justifyContent: "center", alignItems: "center" }}
        >
          <ActivityIndicator size="large" color="#2563EB" />
          <Text style={{ color: "#6B7280", marginTop: 16 }}>
            Generating your session…
          </Text>
        </View>
      ) : (
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{ padding: 20, paddingBottom: 60 }}
          showsVerticalScrollIndicator={false}
        >
          {/* ── Key Badge ── */}
          <View
            style={{
              backgroundColor: "#111827",
              borderRadius: 12,
              padding: 24,
              marginBottom: 16,
              alignItems: "center",
            }}
          >
            <Text
              style={{
                fontSize: 12,
                color: "#6B7280",
                textTransform: "uppercase",
                letterSpacing: 1.5,
                marginBottom: 8,
              }}
            >
              {settings.clef === "treble" ? "𝄞 Treble Clef" : "𝄢 Bass Clef"} ·{" "}
              {timeSig}
            </Text>
            <Text
              style={{
                fontSize: 52,
                fontWeight: "700",
                color: "#FFFFFF",
                letterSpacing: -2,
              }}
            >
              {sessionKey}
            </Text>
            <Text
              style={{
                fontSize: 20,
                color: "#9CA3AF",
                marginTop: 4,
                textTransform: "capitalize",
              }}
            >
              {sessionMode}
            </Text>
            <View style={{ flexDirection: "row", gap: 8, marginTop: 12 }}>
              <View
                style={{
                  paddingHorizontal: 10,
                  paddingVertical: 4,
                  borderRadius: 999,
                  backgroundColor: "#1F2937",
                  borderWidth: 1,
                  borderColor: "#374151",
                }}
              >
                <Text style={{ fontSize: 11, color: "#9CA3AF" }}>
                  {melody.length} notes · {settings.measures} bar
                  {settings.measures > 1 ? "s" : ""}
                </Text>
              </View>
            </View>
          </View>

          {/* ── LISTEN PHASE ── */}
          {phase === "listen" && (
            <>
              <View
                style={{
                  backgroundColor: "#FFFFFF",
                  borderRadius: 12,
                  borderWidth: 1,
                  borderColor: "#E5E7EB",
                  padding: 20,
                  marginBottom: 16,
                }}
              >
                <Text
                  style={{
                    fontSize: 16,
                    fontWeight: "600",
                    color: "#111827",
                    marginBottom: 4,
                  }}
                >
                  Step 1 · Listen
                </Text>
                <Text
                  style={{ fontSize: 13, color: "#6B7280", marginBottom: 20 }}
                >
                  {settings.chordType !== "none"
                    ? "First hear the reference chord, then listen to the full melody."
                    : "Listen to the full melody carefully."}
                </Text>

                <View style={{ flexDirection: "row", gap: 12 }}>
                  {/* Play Chord */}
                  {settings.chordType !== "none" && (
                    <TouchableOpacity
                      onPress={handlePlayChord}
                      disabled={isPlayingChord || isPlayingMelody}
                      style={{
                        flex: 1,
                        paddingVertical: 16,
                        borderRadius: 8,
                        alignItems: "center",
                        borderWidth: 1,
                        backgroundColor: chordPlayed ? "#D1FAE5" : "#FFFFFF",
                        borderColor: chordPlayed ? "#10B981" : "#E5E7EB",
                        opacity: isPlayingChord ? 0.5 : 1,
                      }}
                    >
                      {isPlayingChord ? (
                        <ActivityIndicator size="small" color="#2563EB" />
                      ) : (
                        <>
                          <Text style={{ fontSize: 22, marginBottom: 4 }}>
                            🎵
                          </Text>
                          <Text
                            style={{
                              fontSize: 13,
                              fontWeight: "600",
                              color: chordPlayed ? "#059669" : "#374151",
                            }}
                          >
                            {chordPlayed ? "Chord ✓" : "Play Chord"}
                          </Text>
                        </>
                      )}
                    </TouchableOpacity>
                  )}

                  {/* Play Melody */}
                  <TouchableOpacity
                    onPress={handlePlayMelody}
                    disabled={isPlayingMelody || isPlayingChord}
                    style={{
                      flex: 1,
                      paddingVertical: 16,
                      borderRadius: 8,
                      alignItems: "center",
                      borderWidth: 1,
                      backgroundColor: melodyPlayed ? "#D1FAE5" : "#EFF6FF",
                      borderColor: melodyPlayed ? "#10B981" : "#2563EB",
                      opacity: isPlayingMelody ? 0.5 : 1,
                    }}
                  >
                    {isPlayingMelody ? (
                      <ActivityIndicator size="small" color="#2563EB" />
                    ) : (
                      <>
                        <Volume2
                          color={melodyPlayed ? "#059669" : "#2563EB"}
                          size={24}
                        />
                        <Text
                          style={{
                            fontSize: 13,
                            fontWeight: "600",
                            marginTop: 6,
                            color: melodyPlayed ? "#059669" : "#2563EB",
                          }}
                        >
                          {melodyPlayed ? "Melody ✓" : "Play Melody"}
                        </Text>
                      </>
                    )}
                  </TouchableOpacity>
                </View>
              </View>

              {/* Ready button */}
              <TouchableOpacity
                onPress={() => setPhase("respond")}
                disabled={!melodyPlayed}
                style={{
                  backgroundColor: melodyPlayed ? "#2563EB" : "#E5E7EB",
                  borderRadius: 8,
                  paddingVertical: 16,
                  flexDirection: "row",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 8,
                }}
              >
                <Text
                  style={{
                    fontSize: 16,
                    fontWeight: "600",
                    color: melodyPlayed ? "#FFFFFF" : "#9CA3AF",
                  }}
                >
                  {melodyPlayed
                    ? "Ready — Play It Back"
                    : "Listen to the melody first"}
                </Text>
                {melodyPlayed && <ChevronRight color="#FFFFFF" size={20} />}
              </TouchableOpacity>
            </>
          )}

          {/* ── RESPOND PHASE ── */}
          {phase === "respond" && (
            <>
              <View
                style={{
                  backgroundColor: "#FFFFFF",
                  borderRadius: 12,
                  borderWidth: 1,
                  borderColor: "#E5E7EB",
                  padding: 20,
                  marginBottom: 16,
                }}
              >
                <Text
                  style={{
                    fontSize: 16,
                    fontWeight: "600",
                    color: "#111827",
                    marginBottom: 4,
                  }}
                >
                  Step 2 · Play It Back
                </Text>
                <Text
                  style={{ fontSize: 13, color: "#6B7280", marginBottom: 16 }}
                >
                  {isKeyboard
                    ? `Tap the ${melody.length} notes in order on the keyboard.`
                    : "Play or sing the melody on your instrument, then release."}
                </Text>

                {/* Replay button */}
                <TouchableOpacity
                  onPress={handlePlayMelody}
                  disabled={isPlayingMelody}
                  style={{
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: 8,
                    paddingVertical: 10,
                    borderRadius: 8,
                    borderWidth: 1,
                    borderColor: "#E5E7EB",
                    marginBottom: 20,
                  }}
                >
                  {isPlayingMelody ? (
                    <ActivityIndicator size="small" color="#6B7280" />
                  ) : (
                    <Volume2 color="#6B7280" size={16} />
                  )}
                  <Text
                    style={{
                      fontSize: 13,
                      color: "#6B7280",
                      fontWeight: "500",
                    }}
                  >
                    Replay Melody
                  </Text>
                </TouchableOpacity>

                {/* ── KEYBOARD MODE ── */}
                {isKeyboard ? (
                  <>
                    {/* Progress dots */}
                    <View
                      style={{
                        flexDirection: "row",
                        alignItems: "center",
                        gap: 8,
                        marginBottom: 12,
                      }}
                    >
                      <Text style={{ fontSize: 13, color: "#6B7280" }}>
                        {userNotes.length} / {melody.length} notes
                      </Text>
                      {userNotes.length > 0 && (
                        <TouchableOpacity onPress={handleClearLast}>
                          <RotateCcw color="#EF4444" size={16} />
                        </TouchableOpacity>
                      )}
                    </View>
                    <ScrollView
                      horizontal
                      showsHorizontalScrollIndicator={false}
                      style={{ marginBottom: 16, flexGrow: 0 }}
                    >
                      <View style={{ flexDirection: "row", gap: 6 }}>
                        {melody.map((_, i) => (
                          <View
                            key={i}
                            style={{
                              width: 34,
                              height: 34,
                              borderRadius: 999,
                              backgroundColor:
                                i < userNotes.length ? "#2563EB" : "#E5E7EB",
                              justifyContent: "center",
                              alignItems: "center",
                            }}
                          >
                            <Text
                              style={{
                                fontSize: 11,
                                fontWeight: "600",
                                color:
                                  i < userNotes.length ? "#FFFFFF" : "#9CA3AF",
                              }}
                            >
                              {i < userNotes.length
                                ? userNotes[i]?.slice(0, -1) || "?"
                                : i + 1}
                            </Text>
                          </View>
                        ))}
                      </View>
                    </ScrollView>

                    {/* Piano */}
                    <PianoKeyboard
                      onNotePress={handleKeyPress}
                      userNotes={userNotes}
                      totalExpected={melody.length}
                      clef={settings.clef}
                    />

                    {/* Submit */}
                    {userNotes.length > 0 && (
                      <TouchableOpacity
                        onPress={() => completeSession(userNotes)}
                        style={{
                          marginTop: 20,
                          backgroundColor: "#2563EB",
                          borderRadius: 8,
                          paddingVertical: 14,
                          alignItems: "center",
                        }}
                      >
                        <Text
                          style={{
                            fontSize: 15,
                            fontWeight: "600",
                            color: "#FFFFFF",
                          }}
                        >
                          Submit {userNotes.length} Note
                          {userNotes.length !== 1 ? "s" : ""}
                        </Text>
                      </TouchableOpacity>
                    )}
                  </>
                ) : (
                  /* ── MICROPHONE MODE ── */
                  <View style={{ alignItems: "center", paddingVertical: 8 }}>
                    <TouchableOpacity
                      onPressIn={startRecording}
                      onPressOut={stopRecording}
                      style={{
                        width: 120,
                        height: 120,
                        borderRadius: 999,
                        backgroundColor: isRecording ? "#FEE2E2" : "#FFFFFF",
                        borderWidth: 2,
                        borderColor: isRecording ? "#DC2626" : "#E5E7EB",
                        justifyContent: "center",
                        alignItems: "center",
                      }}
                    >
                      <Mic
                        color={isRecording ? "#DC2626" : "#6B7280"}
                        size={48}
                      />
                    </TouchableOpacity>
                    <Text
                      style={{
                        fontSize: 13,
                        color: "#6B7280",
                        marginTop: 16,
                        textAlign: "center",
                      }}
                    >
                      {isRecording
                        ? "● Recording — release when done"
                        : "Hold to record the full melody"}
                    </Text>
                  </View>
                )}
              </View>

              {/* Retry */}
              {attemptsLeft > 1 && (
                <TouchableOpacity
                  onPress={retrySession}
                  style={{
                    alignSelf: "center",
                    paddingVertical: 12,
                    paddingHorizontal: 24,
                    borderRadius: 999,
                    borderWidth: 1,
                    borderColor: "#E5E7EB",
                    backgroundColor: "#FFFFFF",
                  }}
                >
                  <Text
                    style={{
                      fontSize: 14,
                      fontWeight: "500",
                      color: "#6B7280",
                    }}
                  >
                    Retry ({attemptsLeft - 1} attempt
                    {attemptsLeft - 1 !== 1 ? "s" : ""} left)
                  </Text>
                </TouchableOpacity>
              )}
            </>
          )}
        </ScrollView>
      )}
    </View>
  );
}
